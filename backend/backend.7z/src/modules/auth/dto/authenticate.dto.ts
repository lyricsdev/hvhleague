export interface authenticateDto {
    steamid: string
    password: string
}