import { Mode } from ".prisma/client";

export interface createLobby {
    mode: Mode
}