export interface registerDto {
    steamid: string
    profileurl: String
}